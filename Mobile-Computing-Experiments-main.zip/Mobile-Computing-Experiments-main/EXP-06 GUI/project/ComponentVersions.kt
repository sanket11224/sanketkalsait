object ComponentVersions {

    const val toolbarVersion = "2.0.5"
    const val suggestionInputViewVersion = "1.0.14"
    const val ratingBarVersion = "1.0.2"
    const val imageSliderVersion = "1.0.8"
    const val phoneNumberVersion = "1.0.2"
    const val dialogsVersion = "1.2.5"
    const val cardInputViewVersion = "1.1.2"
    const val quantityPickerViewVersion = "1.2.4"
    const val timelineViewVersion = "1.0.0"
    const val touchDelegatorVersion = "1.0.0"
    const val fitOptionMessageView = "1.0.0"
}
